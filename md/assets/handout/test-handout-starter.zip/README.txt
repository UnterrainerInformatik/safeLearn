Starter project of the handout fixture (md/test-exam-handout.md).
